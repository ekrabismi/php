Flag Icons

�Flags� are 247 icons � in GIF and PNG formats � representing most countries in the world as small pixel icons. These flag icons are available for free use for any purpose with no requirement for attribution. 


About
-----
famfamfam.com is the website of Mark James, a web developer from Birmingham, UK.

This website has not been updated in a while. Try my twitter, or wait for the site refresh!

While I try to read & answer all questions people ask, the volume of enquiries can be often be a little overwhelming � some questions may receive no response, a particularly short message or there may be quite a delay before you receive a response.

If sending me a message regarding icon licencing, please don't expect a response if you ask �I'm using your Silk icon set and linking to you from a footer/credits page, is this OK?� (the answer is yes), if you wish to ask �Do the Flag/Mini icons sets need attribution or a link� (the answer is no � both sets are public domain), or if you wish to ask �Do the icons come in larger sizes?� (Unfortunately not, wysiwyg).

I am not available for freelance design & development work.



License
-------
I also love to hear of my work being used, feel encouraged to send an email with a link or screenshot of the icons in their new home to mjames at gmail dot com. This work is licensed under a Creative Commons Attribution 2.5 License. This means you may use it for any purpose, and make any changes you like. All I ask is that you include a link back to this page in your credits (although a giant link on every page of your website really isn't needed, contact me to discuss specifics).

The icons can also be used under Creative Commons Attribution 3.0 License (Hi Debian folks!) with the following requirements:

    As an author, I would appreciate a reference to my authorship of the Silk icon set contents within a readme file or equivalent documentation for the software which includes the set or a subset of the icons contained within. 



Donate
------
People have expressed a wish to donate a little money. Donating won't get you anything special, other than a warm feeling inside, and possibly urge me to produce more freely available material for my site. 