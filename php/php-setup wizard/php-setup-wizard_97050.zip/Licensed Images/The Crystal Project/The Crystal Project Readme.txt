++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This copyright and license notice covers the images in this directory.
************************************************************************

TITLE:	Crystal Project Icons
AUTHOR:	Everaldo Coelho
SITE:	http://www.everaldo.com
CONTACT: everaldo@everaldo.com

Copyright (c)  2006-2007  Everaldo Coelho.




Philosophy

The equation it�s very simple: put together humanism, psychoanalysis, semiotic and design. You�ll have �interaction design�.

The expression �humanism� generally refers to a series of values and ideals related to the celebration of the human being. The expression, however, has different meanings, that a lot of times are conflicting and I do not intend to get deeper in this discussion here.It is enough to say that when the greek philosopher Protagoras from a reflection said: �The human being as the measure of all things�, he launches the basis on which humanism would be defined.

Crystal is a human-computer interface design project focused on the user. It contains the human being, his ambiguities, feelings, perceptions, cultural and social backgrounds and everything else that can be called �human� as a measure and efforts.



Objectives

Crystal Project exists to create a vivid an consistent experience for the user, through a design delineated by the observation of semiotic, psychologic and anthropologic concepts.



History

2001, Microsoft and Apple released the new versions of its operational systems. Linux, which was already a success in servers, was beginning to dawn as a desktop. I had tested some of the Linux distributions and was really impressed by them. The GUI�s Window Maker, which was similar to the Nextsteep and Gnome interfaces seemed fantastic.

But despite liking other interfaces, KDE was the one that really captivated me. Not as much by the visual, but for the functionality and the fact that it�s easy to use. The interface looked a lot like the MS Windows 98, which in my opinion was easier to use at the time as it was estheticacly problematic. It was in that context that I started to create the Crystal icon theme, which initially had the simple intention to give my Linux Desktop a compatible look with the graphics of the new Windows XP and MacOSX operation systems.

In the same year I was invited to join the marketing department of Conectiva SA, known today as Mandriva. Helio Castro, developer of the KDE and workmate, was the first one to show interest on the graphics and initially released some of my pieces on kdelook.org. There and inside Conectiva as well, the icons had a great acceptance.



Later on the theme would be added to the official KDE.

Today Crystal Project icons are used in thousands of softwares, websites and other media throughout the world.

Thanks to

Thanks to:The entire Crystal users community. You are responsible for the success of this project.

To the artists who collaborated with me on the creation of the icons:

- Ingolfur Haraldsson

- Luiz Claudio dos Santos

- Edson Farias

- Paulo Andr�

- Rhandros Dembiki

- Andr� Souza

To all the people at CrystalXp.net who have done a wonderful job converting the icons to Windows.

To Carlos Rego (Nullmind) from relio.com that hosts and keep this project online.

To Michael Robertson from Linspire that affectionately continues to sustain this project.

To my family, that has supported me despite my absence and shortness of time.

To God that allows me to be.




Participate

Your participation is essential to this project. You can collaborate in three different ways:

1- Send your feedbacks and comments, they are essential in order to determinate the direction we should follow

2- If you are an icon artist, send me a sample of your work and join our team.

3- You can send donations of any importance through Paypal to paypal@crystalproject.org. The Crystal project is non profit, your donations will be very appreciated.
