CREATE TABLE `{dbprefix}blog` (
  `id` int(11) NOT NULL auto_increment,
  `user_idfk` int(11) NOT NULL,
  `owner_idfk` int(11) NOT NULL,
  `dateoftime` int(10) NOT NULL,
  `clock` int(6) NOT NULL,
  `title` varchar(100) NOT NULL,
  `text` text NOT NULL,
  `show` tinyint(1) NOT NULL,
  `seo` varchar(110) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `seo` (`seo`)
);

-- NEXT_QUERY --

CREATE TABLE `{dbprefix}comment` (
  `id` int(11) NOT NULL auto_increment,
  `blog_idfk` int(11) NOT NULL,
  `dateoftime` int(10) NOT NULL,
  `clock` int(6) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `show` tinyint(1) NOT NULL default '1',
  `confirmed` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

-- NEXT_QUERY --

CREATE TABLE `{dbprefix}contact` (
  `id` int(11) NOT NULL auto_increment,
  `subject` varchar(120) default NULL,
  `dateoftime` int(10) NOT NULL,
  `clock` int(6) NOT NULL,
  `name` varchar(100) default NULL,
  `email` varchar(150) default NULL,
  `website` varchar(255) default NULL,
  `phonenumber` varchar(20) NOT NULL,
  `text` text NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

-- NEXT_QUERY --

CREATE TABLE `{dbprefix}setting` (
  `id` int(11) NOT NULL auto_increment,
  `optionkey` varchar(20) NOT NULL,
  `value` text NOT NULL,
  `hashkey` char(32) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `key` (`optionkey`)
);

-- NEXT_QUERY --

CREATE TABLE `{dbprefix}user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `display` varchar(40) NOT NULL default '',
  `email` varchar(255) NOT NULL,
  `level` smallint(2) NOT NULL default '0',
  `hashkey` char(32) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `display` (`display`),
  UNIQUE KEY `email` (`email`)
);